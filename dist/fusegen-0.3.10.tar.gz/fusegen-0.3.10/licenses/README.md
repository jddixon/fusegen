# licenses/README.md

The licenses in this directory are for use in code generation and do
not apply to the code in this package (fusegen), which is covered by
an MIT-style open source license.
