fuseGen
=======

A tool for generating a skeletal Linux FUSE user-space file system.
